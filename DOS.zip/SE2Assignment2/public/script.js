
var search_input = document.getElementById('search-input');
var go = document.getElementById('go');
var search_output = document.getElementsByClassName('search-output');
go.onclick = function(){
    var httpRequest = new XMLHttpRequest();
    var wordText = search_input.value;
    while(true){
        httpRequest.open('GET', '/dictionary?word=' + wordText, false);
        httpRequest.send();
    }
    if(httpRequest.status == 200){
        search_output[0].textContent = httpRequest.responseText;
    }else{
        search_output[0].textContent = "";
    }

}
